import os
import sqlite3
import getpass
from werkzeug.security import generate_password_hash

db_path = os.environ.get("AXAC_DB_PATH", os.path.join(os.path.dirname(__file__), "axac.db"))
username = input("Username owner (3-24 karakter): ").strip()
if not (3 <= len(username) <= 24) or not username.replace("_", "").isalnum():
    raise SystemExit("Username tidak valid.")
password = getpass.getpass("Password owner (minimal 10 karakter): ")
if len(password) < 10:
    raise SystemExit("Password minimal 10 karakter.")
confirm = getpass.getpass("Ulangi password: ")
if password != confirm:
    raise SystemExit("Password tidak sama.")

conn = sqlite3.connect(db_path)
conn.execute("""
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)
""")
try:
    conn.execute(
        "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'owner')",
        (username, generate_password_hash(password))
    )
    conn.commit()
except sqlite3.IntegrityError:
    raise SystemExit("Username sudah digunakan.")
finally:
    conn.close()
print("Akun owner berhasil dibuat. Simpan password di tempat aman.")
