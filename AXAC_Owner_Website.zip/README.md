# AXAC Owner Website

Website Flask + SQLite dengan:
- Registrasi username/password khusus website (tanpa Google)
- Login dan logout
- Password disimpan dalam bentuk hash
- Role `owner` dan `user`
- Owner panel yang dilindungi pemeriksaan role di server
- Layout responsif untuk HP dan desktop

## A. Jalankan di Android (lokal)

1. Instal Termux dari sumber resmi F-Droid atau GitHub Termux.
2. Buka Termux, lalu jalankan:

```sh
pkg update
pkg install python
pip install -r requirements.txt
```

3. Pindahkan folder proyek ini ke penyimpanan Termux. Contoh bila diekstrak di Download:
   - Jalankan `termux-setup-storage`
   - Salin folder `axac_owner_website` dari Download ke folder Home Termux menggunakan file manager.
4. Masuk ke folder proyek, lalu buat secret key dan siapkan environment:

```sh
cd axac_owner_website
export AXAC_SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
pip install -r requirements.txt
python create_owner.py
```

5. Isi username owner dan password minimal 10 karakter saat diminta.
6. Jalankan website:

```sh
python app.py
```

7. Buka Chrome di HP yang sama dan kunjungi:
   `http://127.0.0.1:8080`

Termux harus tetap berjalan selama website lokal dipakai. Alamat 127.0.0.1 hanya bisa diakses dari perangkat itu sendiri.

## B. Agar punya link yang bisa dibuka dari internet

Aplikasi lokal tidak otomatis memiliki link publik. Agar link bisa dibuka dari HP lain atau jaringan lain, proyek harus dijalankan di server online yang mendukung Python/Flask dan menyediakan HTTPS. Unggah folder proyek ke server pilihan, pasang dependensi dari `requirements.txt`, atur `AXAC_SECRET_KEY` sebagai environment variable rahasia, jalankan dengan server WSGI produksi, lalu hubungkan domain jika punya.

Perintah server produksi setelah dependensi dipasang:

```sh
waitress-serve --listen=127.0.0.1:8080 app:app
```

Letakkan reverse proxy HTTPS di depan Waitress pada server publik. Set `AXAC_HTTPS=1` agar cookie sesi hanya dikirim melalui HTTPS. Jangan menjalankan server publik dengan `python app.py`.

## C. Keamanan penting

- Buat akun owner hanya lewat `python create_owner.py`; registrasi publik selalu membuat role `user`.
- Jangan bagikan `AXAC_SECRET_KEY`, file database `axac.db`, atau password owner.
- Simpan salinan cadangan database dengan aman.
- Untuk penggunaan publik, tambahkan pembatasan percobaan login, CSRF protection, dan kebijakan privasi sebelum membuka pendaftaran luas.
- CSS memakai Google Fonts untuk font opsional; layout utama tetap berfungsi bila font eksternal tidak tersedia.
