import os
import sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get("AXAC_DB_PATH", os.path.join(BASE_DIR, "axac.db"))
SECRET_KEY = os.environ.get("AXAC_SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError("Set AXAC_SECRET_KEY before starting the app.")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=SECRET_KEY,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    # Enable this when deployed behind HTTPS:
    SESSION_COOKIE_SECURE=os.environ.get("AXAC_HTTPS", "0") == "1",
)

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        g.db.commit()
        # Optional first-run owner bootstrap for hosted deployments.
        # Set AXAC_OWNER_USERNAME and AXAC_OWNER_PASSWORD in the host's
        # environment settings; never hard-code credentials in this file.
        owner_username = os.environ.get("AXAC_OWNER_USERNAME", "").strip()
        owner_password = os.environ.get("AXAC_OWNER_PASSWORD", "")
        if owner_username and owner_password:
            user_count = g.db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            if user_count == 0:
                g.db.execute(
                    "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'owner')",
                    (owner_username, generate_password_hash(owner_password)),
                )
                g.db.commit()
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return db().execute(
        "SELECT id, username, role, created_at FROM users WHERE id = ?", (uid,)
    ).fetchone()

@app.context_processor
def inject_user():
    return {"logged_user": current_user()}

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Login terlebih dahulu.", "info")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def owner_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            flash("Login terlebih dahulu.", "info")
            return redirect(url_for("login"))
        if user["role"] != "owner":
            return render_template("error.html", code=403,
                                   message="Halaman ini khusus owner."), 403
        return fn(*args, **kwargs)
    return wrapped

@app.get("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not (3 <= len(username) <= 24) or not username.replace("_", "").isalnum():
            flash("Username 3–24 karakter; gunakan huruf, angka, atau underscore.", "error")
            return render_template("register.html")
        if len(password) < 10:
            flash("Password minimal 10 karakter.", "error")
            return render_template("register.html")
        conn = db()
        try:
            conn.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'user')",
                (username, generate_password_hash(password))
            )
            conn.commit()
        except sqlite3.IntegrityError:
            flash("Username sudah dipakai.", "error")
            return render_template("register.html")
        flash("Akun berhasil dibuat. Silakan login.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = db().execute(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            (username,)
        ).fetchone()
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Username atau password salah.", "error")
            return render_template("login.html")
        session.clear()
        session["user_id"] = user["id"]
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.get("/dashboard")
@login_required
def dashboard():
    user = current_user()
    return render_template("dashboard.html", user=user)

@app.get("/owner")
@owner_required
def owner():
    users = db().execute(
        "SELECT id, username, role, created_at FROM users ORDER BY id DESC"
    ).fetchall()
    return render_template("owner.html", users=users)

@app.post("/logout")
def logout():
    session.clear()
    flash("Kamu sudah logout.", "success")
    return redirect(url_for("index"))

@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="Halaman tidak ditemukan."), 404

if __name__ == "__main__":
    # Local development only. For a public deployment, use a production WSGI server.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "8080")), debug=False)
